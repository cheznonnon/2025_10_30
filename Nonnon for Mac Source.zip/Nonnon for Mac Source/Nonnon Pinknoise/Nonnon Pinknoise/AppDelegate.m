//
//  AppDelegate.m
//  Nonnon Pinknoise
//
//  Created by nonnon on 2022/07/05.
//

#import "AppDelegate.h"


#import "../../nonnon/mac/sound.c"
#import "../../nonnon/mac/window.c"

#import "../../nonnon/mac/n_button.c"

#import "../../nonnon/win32/gdi.c"




void
n_pinknoise_gdi( n_bmp *bmp, NSString *arg_text, NSString *arg_icon )
{

	NSBundle *main = [NSBundle mainBundle];
	NSString *icon = [main pathForResource:arg_icon ofType:@"bmp"];


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = 64;
	gdi.sy                  = 64;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_bmp_black_invisible;
	gdi.base_color_fg       = n_bmp_black_invisible;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.text                = n_mac_nsstring2str( arg_text );
	gdi.text_font           = n_posix_literal( "Helvetica" );
	gdi.text_size           = 12;
	gdi.text_style          = N_GDI_TEXT_MAC_BASELINE;

	if ( n_mac_is_darkmode() )
	{
		gdi.text_color_main = n_bmp_rgb_mac( 222,222,222 );
	} else {
		gdi.text_color_main = n_bmp_black;
	}

	gdi.icon                = n_mac_nsstring2str( icon );


	n_gdi_bmp( &gdi, bmp );
//n_bmp_save( bmp, "/Users/nonnon/Desktop/ret.bmp" );


	n_memory_free( gdi.text );
	n_memory_free( gdi.icon );


	return;
}




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;
@property (weak) IBOutlet NonnonButton *n_button;

@end

@implementation AppDelegate {

	AVAudioPlayer *player;
	BOOL           onoff;

}

- (void) n_button_image_change:(BOOL) onoff
{

	NSString *text;
	NSString *icon;
	if ( onoff )
	{
		text = @"Pause";
		icon = @"neko";
	} else {

		text = @"Play";
		icon = @"neko_sleeping";
	}

	n_bmp bmp; n_bmp_zero( &bmp );

	n_pinknoise_gdi( &bmp, text, icon );

	[_n_button n_icon_free];
	[_n_button n_icon_set:&bmp];

	[_n_button display];

}

- (void) n_button_pressed
{
//NSLog( @"!" );

	if ( onoff )
	{
		onoff = FALSE;
		n_mac_sound_pause( player );
	} else {
		onoff = TRUE;
		n_mac_sound_play ( player );
	}

	[self n_button_image_change:onoff];

}

- (void)awakeFromNib
{

	n_mac_image_window = _window;
	n_gdi_scale_factor = n_mac_image_window.backingScaleFactor;

	player = n_mac_sound_wav_init( @"pinknoise" );

	// [!] : repeat forever : gapless playback is very useful
	n_mac_sound_loop_count( player, -1 );

	n_mac_sound_play( player );


	// [!] : check routine
	onoff = TRUE;


	BOOL border_onoff = TRUE;

	{
		[_n_button n_enable:TRUE];
		[_n_button n_border:border_onoff];
		[_n_button n_nswindow_set:_window];
		[_n_button n_direct_click:TRUE];

		[self n_button_image_change:onoff];

		_n_button.delegate = self;
	}


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];


	// [!] : dark mode
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( darkModeChanged: )
		       name: @"AppleInterfaceThemeChangedNotification"
		     object: nil
	];


	// [x] : macOS 15 Sequoia : not working
	//[[self window] miniaturize:self];

	n_mac_timer_init_once( self, @selector( n_timer_method_launch ), 200 );

}

- (void) darkModeChanged:(NSNotification *)notification
{
//NSLog( @"darkModeChanged" );

	[self n_button_image_change:onoff];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		n_mac_sound_stop( player );
		[NSApp terminate:self];
	}
}


- (void) n_timer_method_launch
{
//NSLog( @"n_timer_method_launch" );

	[[self window] miniaturize:self];

}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");
}

- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog(@"mouseUp");

	if ( [_n_button n_is_pressed] )
	{
		[self n_button_pressed];
	}

}


@end
